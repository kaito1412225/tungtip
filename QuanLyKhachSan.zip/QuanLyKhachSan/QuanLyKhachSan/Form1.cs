﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuanLyKhachSan
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            HienThi_Luoi();
            btnSua.Enabled = false;
        }

        private void HienThi_Luoi()
        {
            string sql;



            DataTable tblS;
            sql = "SELECT MaPhong, TenPhong, DonGia FROM tblPhong";
            tblS = ThucthiSQL.DocBang(sql);
            dataGridView1.DataSource = tblS;
            dataGridView1.Columns[0].HeaderText = "Mã Phòng";
            dataGridView1.Columns[1].HeaderText = "Tên Phòng";
            dataGridView1.Columns[2].HeaderText = "Đơn giá";

            dataGridView1.Columns[0].Width = 100;
            dataGridView1.Columns[1].Width = 100;
            dataGridView1.Columns[2].Width = 300;

            dataGridView1.AllowUserToAddRows = false;
            dataGridView1.EditMode = DataGridViewEditMode.EditProgrammatically;
            tblS.Dispose();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int numrow;
            numrow = e.RowIndex;
            txtMaPhong.Text = dataGridView1.Rows[numrow].Cells[0].Value.ToString();
            txtTenPhong.Text = dataGridView1.Rows[numrow].Cells[1].Value.ToString();
            txtDongia.Text = dataGridView1.Rows[numrow].Cells[2].Value.ToString();
            btnSua.Enabled = true;
            btnHuy.Enabled = true;
            txtMaPhong.Enabled = false;
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            txtMaPhong.Text = "";
            txtTenPhong.Text = "";
            txtDongia.Text = "";
            btnSua.Enabled = false;
            btnThem.Enabled = false;
            btnXoa.Enabled = false;
            //btnSua.Enabled = true;
            //btnThem.Enabled = true;
            //btnXoa.Enabled = true;
            btnHuy.Enabled = true;
            btnLuu.Enabled = true;
            txtMaPhong.Enabled = true;
            txtMaPhong.Focus();
        }

        private void btnHuy_Click(object sender, EventArgs e)
        {
            txtMaPhong.Text = "";
            txtTenPhong.Text = "";
            txtDongia.Text = "";
            txtMaPhong.Enabled = true;
            btnHuy.Enabled = false;
            btnLuu.Enabled = false;
            btnThem.Enabled = true;
            btnSua.Enabled = false;
            btnXoa.Enabled = true;
        }

        private void btnLuu_Click(object sender, EventArgs e)
        {
            string sql;
            if (txtMaPhong.Text.Trim().Length == 0)
            {
                MessageBox.Show("Bạn phải nhập mã", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtMaPhong.Focus();
                return;
            }
            if (txtTenPhong.Text.Trim().Length == 0)
            {
                MessageBox.Show("Bạn phải nhập tên", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtTenPhong.Focus();
                return;
            }
            if (txtDongia.Text.Trim().Length == 0)
            {
                MessageBox.Show("Bạn phải nhập đơn giá", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtDongia.Focus();
                return;
            }

            sql = "SELECT MaPhong FROM tblPhong WHERE MaPhong = N'" + txtMaPhong.Text.Trim() + "'";
            DataTable tblTour = ThucthiSQL.DocBang(sql);
            if (tblTour.Rows.Count > 0)
            {
                MessageBox.Show("Mã này đã có, bạn phải nhập mã khác", "Thông Báo");
                txtMaPhong.Focus();
                txtMaPhong.Text = "";
                return;
            }
            //chú ý string :chữ cái S đầu phải là chữ thường (DÙNG ĐỂ KHAI BÁO )
            sql = "INSERT INTO tblPhong(MaPhong, TenPhong, DonGia) VALUES(N'" + txtMaPhong.Text.Trim() + "',N'" + txtTenPhong.Text.Trim() + "', " + txtDongia.Text.Trim() + ")";
            //sql = "INSERT INTO tbltour(Matour, Tentour, Dongia) VALUES "+
            //  "(N'" + txtMatour.Text + "',N'" +
            //txtTentour.Text + "'," + txtDongia.Text + ")";
            ThucthiSQL.CapNhatDuLieu(sql);
            HienThi_Luoi();
            btnThem.Enabled = true;
            btnSua.Enabled = false;
            btnXoa.Enabled = true;
            btnHuy.Enabled = false;
            btnLuu.Enabled = false;
            //txtMatour.Enabled = false;
        }

        private void btnSua_Click(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow.Cells["MaPhong"].Value.ToString() == "")
            {
                MessageBox.Show("Không có dữ liệu", "Thông Báo");
                return;
            }
            //txtMatour.Text = dataGridView1.CurrentRow.Cells["Matour"].Value.ToString();
            //txtTentour.Text = dataGridView1.CurrentRow.Cells["Tentour"].Value.ToString();
            //txtDongia.Text = dataGridView1.CurrentRow.Cells["Dongia"].Value.ToString();
            string sql;
            DataTable tblTour;
            sql = "SELECT MaPhong, TenPhong, DonGia FROM tblPhong";
            tblTour = ThucthiSQL.DocBang(sql);

            if (txtMaPhong.Text.Trim().Length == 0)
            {
                MessageBox.Show("bạn phải nhập mã", "thông báo");
                txtMaPhong.Focus();
                return;
            }
            if (txtTenPhong.Text.Trim().Length == 0)
            {
                MessageBox.Show("bạn phải nhập tên  ", "thông báo");
                txtTenPhong.Focus();
                return;
            }
            if (txtDongia.Text.Trim().Length == 0)
            {
                MessageBox.Show("bạn phải nhập đơn giá", "thông báo");
                txtDongia.Focus();
                return;
            }
            sql = "UPDATE tblPhong SET TenPhong=N'" + txtTenPhong.Text.Trim() +
                "',DonGia=" + txtDongia.Text.Trim() +
                " WHERE MaPhong=N'" + txtMaPhong.Text.Trim() + "'";
            ThucthiSQL.CapNhatDuLieu(sql);
            HienThi_Luoi();
            txtMaPhong.Text = "";
            txtTenPhong.Text = "";
            txtDongia.Text = "";
            btnHuy.Enabled = false;
            //txtMatour.Enabled = false;
            btnSua.Enabled = false;
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            string sql;
            string ms;
            if (dataGridView1.CurrentRow.Cells["MaPhong"].Value.ToString() == "")
            {
                MessageBox.Show("Không có dữ liệu !", "Thông báo");
                return;
            }
            ms = dataGridView1.CurrentRow.Cells["MaPhong"].Value.ToString();
            if (MessageBox.Show("Bạn có muốn xóa không ?", "Thông Báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                //string ma = dataGridView1.CurrentRow.Cells["Masach"].Value.ToString();
                sql = "DELETE tblPhong WHERE MaPhong = N'" + ms + "'";
                ThucthiSQL.CapNhatDuLieu(sql);
                HienThi_Luoi();
            }

        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void txtDongia_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }

            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }

        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int numrow;
            numrow = e.RowIndex;
            txtMaPhong.Text = dataGridView1.Rows[numrow].Cells[0].Value.ToString();
            txtTenPhong.Text = dataGridView1.Rows[numrow].Cells[1].Value.ToString();
            txtDongia.Text = dataGridView1.Rows[numrow].Cells[2].Value.ToString();
            btnSua.Enabled = true;
            btnHuy.Enabled = true;
            txtMaPhong.Enabled = false;
        }
    }
}
